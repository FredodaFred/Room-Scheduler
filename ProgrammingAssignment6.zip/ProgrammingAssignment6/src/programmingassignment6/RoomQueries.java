/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programmingassignment6;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author Freddy
 */
public class RoomQueries {

    private static Connection connection = DBConnection.getConnection();

    /**
     * 
     * @return - ArrayList<RoomEntry> of all the rooms that exist in the ROOMS database
     */
    public static ArrayList<RoomEntry> getAllPossibleRooms() {

        ArrayList<RoomEntry> allRooms = new ArrayList<RoomEntry>();
        try {
            PreparedStatement allRoomsRequest = connection.prepareStatement("SELECT NAME, SEATS FROM ROOMS");
            ResultSet allRoomsResult = allRoomsRequest.executeQuery();
            while (allRoomsResult.next()) {
                allRooms.add(new RoomEntry(allRoomsResult.getString("NAME"), allRoomsResult.getInt("SEATS")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return allRooms;
    }

    public static ArrayList<String> getAllPossibleRoomsStr() {

        ArrayList<String> allRooms = new ArrayList<String>();
        try {
            PreparedStatement allRoomsRequest = connection.prepareStatement("SELECT NAME, SEATS FROM ROOMS");
            ResultSet allRoomsResult = allRoomsRequest.executeQuery();
            while (allRoomsResult.next()) {
                allRooms.add(allRoomsResult.getString("name"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return allRooms;
    }

    /**
     * Return -1 if nothing found 
     * @param name
     * @return 
     */
    public static int getRoomSeats(String name) {
        try {
            PreparedStatement roomsRequest = connection.prepareStatement("SELECT SEATS FROM ROOMS WHERE NAME = ?");
            roomsRequest.setString(1, name);
            ResultSet roomsResult = roomsRequest.executeQuery();
            return roomsResult.getInt("seats");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    public static void addRoom(RoomEntry newRoom) {
        try {
            PreparedStatement injectRoom = connection.prepareStatement("INSERT INTO ROOMS NAME, SEATS" + "VALUE(?, ?)");
            injectRoom.setString(1, newRoom.getName());
            injectRoom.setInt(2, newRoom.getSeats());
            injectRoom.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void dropRoom(RoomEntry room) {
        try {
            PreparedStatement injectRoom = connection.prepareStatement("DELETE FROM ROOMS WHERE NAME = ?");
            injectRoom.setString(1, room.getName());
            //injectRoom.setInt(2, room.getSeats());
            injectRoom.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programmingassignment6;

/**
 *
 * @author Freddy
 */
public class RoomEntry implements Comparable<RoomEntry> {
    
    private String name;
    private int seats;
    
    public RoomEntry(String name, int seats){
        this.name = name;
        this.seats = seats;
    }

    public String getName() {
        return name;
    }

    public int getSeats() {
        return seats;
    }
    
    /**
     * This is so we can sort by seats
     * @param o
     * @return 
     */
    @Override
    public int compareTo(RoomEntry o){
        return this.seats - o.seats;
    }
    @Override 
    public String toString(){
        return name;
    }
}

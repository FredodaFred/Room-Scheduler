/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programmingassignment6;

import java.sql.Connection;
import java.util.ArrayList;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Date;

/**
 *
 * @author Freddy
 */
public class ReservationQueries {

    private static Connection connection = DBConnection.getConnection();

    /**
     * Go to the reservation database, and return the rooms based on the date
     *
     * @param date
     * @return RoomEntry based on the date
     */
    public static ArrayList<RoomEntry> getRoomsReservedByDate(Date date) {
        ArrayList<RoomEntry> dateRooms = new ArrayList<RoomEntry>();
        try {
            PreparedStatement dateRoomsRequest = connection.prepareStatement("SELECT ROOM, SEATS FROM RESERVATIONS WHERE DATE = ?");
            dateRoomsRequest.setDate(1, date);
            ResultSet dateRoomsResult = dateRoomsRequest.executeQuery();
            while (dateRoomsResult.next()) {
                dateRooms.add(new RoomEntry(dateRoomsResult.getString("room"), dateRoomsResult.getInt("seats")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return dateRooms;
    }

    /**
     * Like the method above, but returns reservation entries instead
     *
     * @return
     */
    public static ArrayList<ReservationEntry> getReservationsByDate(Date date) {
        ArrayList<ReservationEntry> reservations = new ArrayList<ReservationEntry>();
        try {
            PreparedStatement reservationRequest = connection.prepareStatement("SELECT * FROM RESERVATIONS WHERE DATE = ?");
            reservationRequest.setDate(1, date);
            ResultSet result = reservationRequest.executeQuery();
            while (result.next()) {
                reservations.add(new ReservationEntry(result.getString("faculty"), result.getString("room"),
                        result.getDate("date"), result.getInt("seats"), result.getTimestamp("timestamp")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return reservations;
    }

    public static void addReservationEntry(ReservationEntry reservation) {
        try {
            PreparedStatement insert = connection.prepareStatement("INSERT INTO RESERVATIONS (FACULTY, ROOM, DATE, SEATS, TIMESTAMP) VALUES(?, ?, ?, ?, ?)");
            insert.setString(1, reservation.getFaculty());
            insert.setString(2, reservation.getRoom());
            insert.setDate(3, reservation.getDate());
            insert.setInt(4, reservation.getSeats());
            insert.setTimestamp(5, reservation.getTimestamp());
            insert.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public static ArrayList<ReservationEntry> getAllReservations(){
        ArrayList<ReservationEntry> reservations = new ArrayList<ReservationEntry>();
        try{
            PreparedStatement query = connection.prepareStatement("SELECT * FROM RESERVATIONS");
            ResultSet result = query.executeQuery();
            
            while(result.next()){
                reservations.add(new ReservationEntry(result.getString("faculty"), result.getString("room"),
                result.getDate("date"), result.getInt("seats"), result.getTimestamp("timestamp")));
            }
            
        }
        catch(SQLException e){
            e.printStackTrace();
        }
        return reservations;
    }

    public static ArrayList<ReservationEntry> getReservationsByFaculty(String faculty) {
        ArrayList<ReservationEntry> reservations = new ArrayList<ReservationEntry>();
        try {
            PreparedStatement reservationRequest = connection.prepareStatement("SELECT FACULTY, ROOM, DATE, SEATS, TIMESTAMP FROM RESERVATIONS WHERE FACULTY = ?");
            reservationRequest.setString(1, faculty);
            ResultSet result = reservationRequest.executeQuery();
            while (result.next()) {
                reservations.add(new ReservationEntry(result.getString("faculty"), result.getString("room"),
                        result.getDate("date"), result.getInt("seats"), result.getTimestamp("timestamp")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return reservations;
    }

    public static void deleteReservation(ReservationEntry reservation) {
        try {
            PreparedStatement deleteRequest = connection.prepareStatement("DELETE FROM RESERVATIONS WHERE FACULTY = ?, ROOM = ?, DATE = ?, SEATS = ?");
            deleteRequest.setString(1, reservation.getFaculty());
            deleteRequest.setString(2, reservation.getRoom());
            deleteRequest.setDate(3, reservation.getDate());
            deleteRequest.setInt(4, reservation.getSeats());
            deleteRequest.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}

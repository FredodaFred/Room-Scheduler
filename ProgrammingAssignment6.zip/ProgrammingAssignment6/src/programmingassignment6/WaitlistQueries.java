/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programmingassignment6;

import java.sql.Connection;
import java.util.ArrayList;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Date;

/**
 *
 * @author Freddy
 */
public class WaitlistQueries {

    private static Connection connection = DBConnection.getConnection();

    public static ArrayList<WaitlistEntry> getWaitlistByDate(Date date) {
        ArrayList<WaitlistEntry> waitlist = new ArrayList<WaitlistEntry>();
        try {
            PreparedStatement query = connection.prepareStatement("SELECT FACULTY, SEATS, TIMESTAMP FROM WAITLIST WHERE DATE = ?");
            query.setDate(1, date);
            ResultSet result = query.executeQuery();
            while (result.next()) {
                waitlist.add(new WaitlistEntry(result.getString("faculty"), date, result.getInt("seats"), result.getTimestamp("timestamp")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return waitlist;
    }

    public static ArrayList<WaitlistEntry> getWaitlistByFaculty(String faculty) {
        ArrayList<WaitlistEntry> waitlist = new ArrayList<WaitlistEntry>();
        try {
            PreparedStatement query = connection.prepareStatement("SELECT DATE, SEATS, TIMESTAMP FROM WAITLIST WHERE FACULTY = ?");
            query.setString(1, faculty);
            ResultSet result = query.executeQuery();
            while (result.next()) {
                waitlist.add(new WaitlistEntry(faculty, result.getDate("date"), result.getInt("seats"), result.getTimestamp("timestamp")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return waitlist;
    }
    public static ArrayList<WaitlistEntry> getAllWaitlistEntries(){
        ArrayList<WaitlistEntry> waitlist = new ArrayList<WaitlistEntry>();
        try {
            PreparedStatement query = connection.prepareStatement("SELECT FACULTY, DATE, SEATS, TIMESTAMP FROM WAITLIST");
            ResultSet result = query.executeQuery();
            while (result.next()) {
                
                WaitlistEntry entry = new WaitlistEntry(result.getString("faculty"), result.getDate("date"), result.getInt("seats"), result.getTimestamp("timestamp"));
                waitlist.add(entry);
                System.out.println(entry.getFaculty() +entry.getDate().toString() +Integer.toString(entry.getSeats()) + entry.getTimestamp().toString());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return waitlist;        
        
    }

    public static void addWaitlistEntry(WaitlistEntry entry) {
        try {
            PreparedStatement query = connection.prepareStatement("INSERT INTO WAITLIST (FACULTY, DATE, SEATS, TIMESTAMP)" + " VALUES(?, ?, ?, ?)");
            query.setString(1, entry.getFaculty());
            query.setDate(2, entry.getDate());
            query.setInt(3, entry.getSeats());
            query.setTimestamp(4, entry.getTimestamp());
            query.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();

        }
    }

    public static void deleteWaitlistEntry(WaitlistEntry entry) {
        try {
            PreparedStatement query = connection.prepareStatement("DELETE FROM WAITLIST WHERE FACULTY = ?, DATE = ?, SEATS = ?, TIMESTAMP = ?");
            query.setString(1, entry.getFaculty());
            query.setDate(2, entry.getDate());
            query.setInt(3, entry.getSeats());
            query.setTimestamp(4, entry.getTimestamp());
            query.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();

        }
    }

}

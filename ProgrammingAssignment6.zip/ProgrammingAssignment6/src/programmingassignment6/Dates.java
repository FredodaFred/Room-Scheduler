/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package programmingassignment6;

import java.sql.Date;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
/**
 *
 * @author Freddy
 */
public class Dates {
    
    private static Connection connection = DBConnection.getConnection();
    
    public static void addDate(Date date){
        try {
            PreparedStatement insert = connection.prepareStatement("INSERT INTO DATES DATE" + "VALUES(?)");
            insert.setDate(1, date);
            insert.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public static ArrayList<Date> getAllDates(){
        ArrayList<Date> dates = new ArrayList<Date>();
         try {
            PreparedStatement query = connection.prepareStatement("SELECT DATE FROM DATES");
            ResultSet results =  query.executeQuery();
            while(results.next()){
                dates.add(results.getDate("date"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
         return dates;
    }
}
